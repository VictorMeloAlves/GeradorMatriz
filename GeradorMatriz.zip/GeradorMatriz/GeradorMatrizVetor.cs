using System;

namespace GeradorMatriz{
  
  public static class Gerador
  {
      private static Random random = new Random();

      public static double[,] GerarMatriz(int n)
      {
          double[,] matriz = new double[n, n];
          for (int i = 0; i < n; i++)
          {
              for (int j = 0; j < n; j++)
              {
                  matriz[i, j] = random.Next(1,99);
              }
          }
          return matriz;
      }

      public static double[] GerarVetor(int n)
      {
          double[] vetor = new double[n];
          for (int i = 0; i < n; i++)
          {
              vetor[i] = random.Next(1,99);
          }
          return vetor;
      }
  }

}