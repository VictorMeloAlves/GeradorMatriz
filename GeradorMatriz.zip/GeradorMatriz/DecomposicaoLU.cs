using System;

namespace GeradorMatriz{
  public class DecomposicaoLU : IStrategyDecomposicao
  {
      public void Decompor(double[,] matriz, out double[,] inferior, out double[,] superior)
      {
          int n = matriz.GetLength(0);
          inferior = new double[n, n];
          superior = new double[n, n];

          for (int i = 0; i < n; i++)
          {
              for (int k = i; k < n; k++)
              {
                  double soma = 0;
                  for (int j = 0; j < i; j++)
                  {
                      soma += (inferior[i, j] * superior[j, k]);
                  }
                  superior[i, k] = matriz[i, k] - soma;
              }

              for (int k = i; k < n; k++)
              {
                  if (i == k)
                      inferior[i, i] = 1;
                  else
                  {
                      double soma = 0;
                      for (int j = 0; j < i; j++)
                      {
                          soma += (inferior[k, j] * superior[j, i]);
                      }
                      inferior[k, i] = (matriz[k, i] - soma) / superior[i, i];
                  }
              }
          }
      }
  }

}