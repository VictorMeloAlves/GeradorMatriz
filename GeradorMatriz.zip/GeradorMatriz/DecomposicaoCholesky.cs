using System;

namespace GeradorMatriz{
  
  public class DecomposicaoCholesky : IStrategyDecomposicao
  {
      public void Decompor(double[,] matriz, out double[,] inferior, out double[,] superior)
      {
          int n = matriz.GetLength(0);
          inferior = new double[n, n];
          superior = new double[n, n];

          for (int i = 0; i < n; i++)
          {
              for (int j = 0; j <= i; j++)
              {
                  double soma = 0;

                  for (int k = 0; k < j; k++)
                  {
                      soma += inferior[i, k] * inferior[j, k];
                  }

                  if (i == j)
                  {
                      inferior[i, j] = Math.Sqrt(matriz[i, i] - soma);
                  }
                  else
                  {
                      inferior[i, j] = (matriz[i, j] - soma) / inferior[j, j];
                  }
              }
          }

          // Superior é a transposta de inferior
          for (int i = 0; i < n; i++)
          {
              for (int j = 0; j < n; j++)
              {
                  superior[i, j] = inferior[j, i];
              }
          }
      }
  }

}