using System;

namespace GeradorMatriz{
    
  public class EliminacaoGauss : IStrategyEliminacao
  {
      public double[] Resolver(double[,] matriz, double[] vetor)
      {
          int n = matriz.GetLength(0);
          double[,] matrizAumentada = new double[n, n + 1];

          for (int i = 0; i < n; i++)
          {
              for (int j = 0; j < n; j++)
              {
                  matrizAumentada[i, j] = matriz[i, j];
              }
              matrizAumentada[i, n] = vetor[i];
          }

          for (int i = 0; i < n; i++)
          {
              for (int k = i + 1; k < n; k++)
              {
                  double t = matrizAumentada[k, i] / matrizAumentada[i, i];
                  for (int j = 0; j <= n; j++)
                  {
                      matrizAumentada[k, j] -= t * matrizAumentada[i, j];
                  }
              }
          }

          double[] solucao = new double[n];
          for (int i = n - 1; i >= 0; i--)
          {
              solucao[i] = matrizAumentada[i, n];
              for (int j = i + 1; j < n; j++)
              {
                  solucao[i] -= matrizAumentada[i, j] * solucao[j];
              }
              solucao[i] /= matrizAumentada[i, i];
          }

          return solucao;
      }
  }

}