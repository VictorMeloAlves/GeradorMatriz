using System;

namespace GeradorMatriz{

  class Program
  {
      static void Main(string[] args)
      {

          Random range = new Random();
        
          int n = (int)range.NextInt64(2, 10);

          double[,] matriz = Gerador.GerarMatriz(n);
          double[] vetor = Gerador.GerarVetor(n);

          Console.WriteLine("Matriz:");
          ImprimirMatriz(matriz);

          Console.WriteLine("Vetor:");
          ImprimirVetor(vetor);

          ResolvedorMatriz resolvedor;

          // Decomposição LU
          resolvedor = new ResolvedorMatriz(new DecomposicaoLU());
          resolvedor.DecomporMatriz(matriz, out double[,] inferiorLU, out double[,] superiorLU);
          Console.WriteLine("Matriz Inferior LU:");
          ImprimirMatriz(inferiorLU);
          Console.WriteLine("Matriz Superior LU:");
          ImprimirMatriz(superiorLU);

          // Decomposição Cholesky
          resolvedor = new ResolvedorMatriz(new DecomposicaoCholesky());
          resolvedor.DecomporMatriz(matriz, out double[,] inferiorCholesky, out double[,] superiorCholesky);
          Console.WriteLine("Matriz Inferior Cholesky:");
          ImprimirMatriz(inferiorCholesky);
          Console.WriteLine("Matriz Superior Cholesky:");
          ImprimirMatriz(superiorCholesky);

          // Eliminação de Gauss
          resolvedor = new ResolvedorMatriz(new EliminacaoGauss());
          double[] solucao = resolvedor.ResolverMatriz(matriz, vetor);
          Console.WriteLine("Solução usando Eliminação de Gauss:");
          ImprimirVetor(solucao);
      }

      static void ImprimirMatriz(double[,] matriz)
      {
          int n = matriz.GetLength(0);
          for (int i = 0; i < n; i++)
          {
              for (int j = 0; j < n; j++)
              {
                  Console.Write("{0:N2}\t", matriz[i, j]);
              }
              Console.WriteLine();
          }
      }

      static void ImprimirVetor(double[] vetor)
      {
          foreach (var val in vetor)
          {
              Console.WriteLine("{0:N2}", val);
          }
      }
  }

}