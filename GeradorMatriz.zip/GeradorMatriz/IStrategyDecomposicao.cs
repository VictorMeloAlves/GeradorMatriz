using System;

namespace GeradorMatriz{
  public interface IStrategyDecomposicao
  {
      void Decompor(double[,] matriz, out double[,] inferior, out double[,] superior);
  }

  public interface IStrategyEliminacao
  {
      double[] Resolver(double[,] matriz, double[] vetor);
  }

}