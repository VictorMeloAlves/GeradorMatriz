using System;

namespace GeradorMatriz{
  
  public class ResolvedorMatriz
  {
      private IStrategyDecomposicao strategyDecomposicao;
      private IStrategyEliminacao strategyEliminacao;

      public ResolvedorMatriz(IStrategyDecomposicao strategyDecomposicao)
      {
          this.strategyDecomposicao = strategyDecomposicao;
      }

      public ResolvedorMatriz(IStrategyEliminacao strategyEliminacao)
      {
          this.strategyEliminacao = strategyEliminacao;
      }

      public void DecomporMatriz(double[,] matriz, out double[,] inferior, out double[,] superior)
      {
          if (strategyDecomposicao == null)
              throw new InvalidOperationException("Estratégia de decomposição não definida.");

          strategyDecomposicao.Decompor(matriz, out inferior, out superior);
      }

      public double[] ResolverMatriz(double[,] matriz, double[] vetor)
      {
          if (strategyEliminacao == null)
              throw new InvalidOperationException("Estratégia de eliminação não definida.");

          return strategyEliminacao.Resolver(matriz, vetor);
      }
  }

}